# Python Side Project: Web Scraping for course information

Description: This Python side project scraps all UWaterloo course information from its website, and exports all these information into an Excel file. This script used BeautifulSoup from bs4, request, and csv Python libraries to achieve such goal.

Please read version 2 first. (all uw course v2.py)

Project Finish Date: September 3, 2018

Please do not spam their website. 
